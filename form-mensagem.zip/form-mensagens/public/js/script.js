// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Adiciona um evento de clique ao botão de envio no formulário de mensagem
    const formEnviarMensagem = document.querySelector('form[action="/enviar-mensagem"]');
    if (formEnviarMensagem) {
        formEnviarMensagem.addEventListener('submit', (event) => {
            // Aqui você pode adicionar validações ou outras ações antes de enviar o formulário
            console.log('Formulário de envio de mensagem enviado.');
        });
    }

    // Adiciona um evento de clique ao botão de ver mensagem no formulário de visualização
    const formVerMensagem = document.querySelector('form[action="/ver-mensagem"]');
    if (formVerMensagem) {
        formVerMensagem.addEventListener('submit', (event) => {
            // Aqui você pode adicionar validações ou outras ações antes de enviar o formulário
            console.log('Formulário de visualização de mensagem enviado.');
        });
    }
});
