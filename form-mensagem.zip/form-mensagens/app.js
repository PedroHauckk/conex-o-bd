const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const crypto = require('crypto');

const app = express();
const port = 3000;

// Configuração do banco de dados MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Substitua com seu usuário do MySQL
    password: '', // Substitua com sua senha do MySQL
    database: 'mensagenss_db'
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
    } else {
        console.log('Conectado ao banco de dados MySQL.');
    }
});

// Chave secreta e IV para criptografia e descriptografia
const SECRET_KEY = crypto.randomBytes(32); // Use uma chave segura e mantenha-a em segredo
const IV = crypto.randomBytes(16); // Vetor de inicialização

// Função para criptografar texto
function encrypt(text) {
    const cipher = crypto.createCipheriv('aes-256-cbc', SECRET_KEY, IV);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return encrypted;
}

// Função para descriptografar texto
function decrypt(text) {
    const decipher = crypto.createDecipheriv('aes-256-cbc', SECRET_KEY, IV);
    let decrypted = decipher.update(text, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

// Middleware para servir arquivos estáticos e processar dados do formulário
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Rota para a página inicial
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Rota para processar o envio da mensagem
app.post('/enviar-mensagem', (req, res) => {
    const { nome, email, mensagem } = req.body;

    // Criptografa o nome, o e-mail e a mensagem antes de salvar no banco de dados
    const encryptedName = encrypt(nome);
    const encryptedEmail = encrypt(email);
    const encryptedMessage = encrypt(mensagem);

    const sql = 'INSERT INTO mensagens (nome, email, mensagem) VALUES (?, ?, ?)';
    db.query(sql, [encryptedName, encryptedEmail, encryptedMessage], (err, result) => {
        if (err) {
            console.error('Erro ao inserir mensagem:', err);
            res.send('Erro ao enviar a mensagem.');
        } else {
            res.redirect('/mensagem-enviada.html');
        }
    });
});

// Rota para a página de confirmação
app.get('/mensagem-enviada.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'mensagem-enviada.html'));
});

// Rota para visualizar a mensagem com base no ID
app.get('/ver-mensagem', (req, res) => {
    const { id } = req.query;

    const sql = 'SELECT * FROM mensagens WHERE id = ?';
    db.query(sql, [id], (err, results) => {
        if (err) {
            console.error('Erro ao buscar mensagem:', err);
            res.send('Erro ao buscar a mensagem.');
        } else if (results.length === 0) {
            res.send('Mensagem não encontrada.');
        } else {
            const mensagem = results[0];
            // Descriptografa o nome, o e-mail e a mensagem antes de exibir
            const decryptedName = decrypt(mensagem.nome);
            const decryptedEmail = decrypt(mensagem.email);
            const decryptedMessage = decrypt(mensagem.mensagem);

            res.send(`
                <h1>Mensagem Encontrada</h1>
                <p><strong>Nome:</strong> ${decryptedName}</p>
                <p><strong>E-mail:</strong> ${decryptedEmail}</p>
                <p><strong>Mensagem:</strong> ${decryptedMessage}</p>
                <a href="/">Voltar</a>
            `);
        }
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
